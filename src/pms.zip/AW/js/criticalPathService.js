
/**
 * Simple Alert service for sample command Handlers
 *
 * @module js/criticalPathService
 */

import app from 'app';
import appCtxSvc from 'js/appCtxService';
import soaService from 'soa/kernel/soaService';
import msgSvc from 'js/messagingService';
// import util from 'js/splmTableUtils';
// import cdmService from 'soa/kernel/clientDataModel';
import eventBus from 'js/eventBus';
import commandPanelService from 'js/commandPanel.service';
// import tcViewModelObjectSvc from 'js/tcViewModelObjectService';
import viewModelObjectSvc from 'js/viewModelObjectService';
import _ from 'lodash';

var exports = {};
/**
 * Dummy alert.
 * @param {String} text - text to display
 */

export const createCPPanelOpen = async (data, ctx) => {
  return commandPanelService.activateCommandPanel("m2_createCPPanel", "aw_toolsAndInfo");
}

export const getNextItemId = () => {
  let input = {
    vInfoForNextId: [
      {
        "typeName": "M2_CriticalPath",
        "propName": "item_id",
        "pattern": ""
      }
    ]
  }

  return soaService.post("Core-2008-06-DataManagement", "getNextIds", input);
}

export const createObjects = async (data, ctx) => {
  if (data.data && data.data.revisionID && data.data.objName) {

    let getNextID = await getNextItemId();
    const itemID = getNextID.nextIds[0];
    const objectDesc = data.data.objDesc.dbValue ? data.data.objDesc.dbValue : ""
    const objectName = data.data.objName.dbValue;
    const revisionID = data.data.revisionID.dbValue;

    if (ctx.xrtSummaryContextObject) {
      if (ctx.xrtSummaryContextObject.props.IMAN_reference.dbValues.length > 0) {
        eventBus.publish("CPCreate.complete");
        return;
      }
    }
    if (ctx.pselected.props.IMAN_reference.dbValues.length > 0) {
      eventBus.publish("CPCreate.complete");
      return;
    }

    const createdCP = await createObject("M2_CriticalPath", itemID, objectDesc, objectName, revisionID);

    if (createdCP.length > 0) {
      const scheduleObject = ctx.pselected;
      await createRelations("IMAN_reference", [scheduleObject], createdCP[0]);
      await createRelations("IMAN_reference", [createdCP[0]], scheduleObject);
    }

    const schduleTasks = data.filterResults.objects.map(o => o.props.awp0Relationship.parentUid/* cdmService.getObject( o.props.awp0Relationship.parentUid ) */);
    await setProperties(createdCP[0], "m2_ScheduleList", schduleTasks);
    eventBus.publish('awsidenav.openClose', {
      id: 'aw_toolsAndInfo',
      commandId: "m2_createCPPanel"
    });

    if (data.data.showObject.dbValue) {
      moveToPage(createdCP[0]);
    }
  }
}

const moveToPage = (modelObject, tabName = "tc_xrt_overview", page = "com_siemens_splm_clientfx_tcui_xrt_showObject") => {
  while (page.includes("_")) {
    page = _.replace(page, "_", ".");
  }
  window.location.replace(document.location.href.split("#")[0] + "#/" + page + "?uid=" + modelObject.uid + "&spageId=" + tabName);
}

const setProperties = async (object, property, values) => {
  let input = {
    info: [{
      object: object,
      vecNameVal:
        [{
          name: property,
          values: values
        }]
    }]
  }
  await soaService.post("Core-2010-09-DataManagement", "setProperties", input);
}

const createObject = async (type, itemId, description, name, revId) => {
  let soaInputParam = {
    inputs: [
      {
        "clientId": "CreateObject",
        "createData": {
          "boName": type,
          "propertyNameValues": {
            "item_id": [itemId],
            "object_name": [name],
            "object_desc": [description],
          },
          "compoundCreateInput": {
            "revision": [
              {
                "boName": type + "Revision",
                "propertyNameValues": {
                  "item_revision_id": [revId],
                },
                "compoundCreateInput": {}
              }
            ]
          }
        },
        "dataToBeRelated": {},
        "workflowData": {},
        "pasteProp": "",
        "targetObject": {
          "uid": "AAAAAAAAAAAAAA",
          "type": "unknownType"
        }
      }
    ]
  }
  let createdCP = await soaService.post('Core-2016-09-DataManagement', 'createAttachAndSubmitObjects', soaInputParam);
  const targetRevision = createdCP.output[0].objects.filter(obj => obj.type == "M2_CriticalPathRevision");
  return targetRevision;
}

const createRelations = async (relationType, primaryArr, secondary) => {

  let soaInputParam = {
    input: []
  };

  for (let primary of primaryArr) {
    soaInputParam.input.push(
      {
        "primaryObject": {
          type: primary.type,
          uid: primary.uid
        },
        "secondaryObject": {
          type: secondary.type,
          uid: secondary.uid
        },
        "relationType": relationType,
        "clientId": "",
        "userData": {
          "uid": "AAAAAAAAAAAAAA",
          "type": "unknownType"
        }
      }
    )
  }

  return await soaService.post('Core-2006-03-DataManagement', 'createRelations', soaInputParam);
}

export const reviseCP = async (data, ctx) => {
  let beforeRevId = ctx.xrtSummaryContextObject.props.item_revision_id.dbValue;
  let input = {
    input: [
      [{
        type: ctx.xrtSummaryContextObject.type,
        uid: ctx.xrtSummaryContextObject.uid
      }],
      [{
        name: ctx.xrtSummaryContextObject.props.object_name.dbValue,
        revId: String.fromCharCode(beforeRevId.charCodeAt() + 1)
      }]
    ]
  }

  let res = await soaService.post('Core-2006-03-DataManagement', 'revise', input).catch((e) => {
    console.log(e.message);
  });
  let revisedRevision = res.oldItemRevToNewItemRev[1][0];
  const schduleTasks = data.filterResults.objects.map(o => o.props.awp0Relationship.parentUid);
  await setProperties(revisedRevision, "m2_ScheduleList", schduleTasks);
  moveToPage(revisedRevision);
}

export const reviseCPEvent = () => {
  eventBus.publish("CPRevise.check");
  eventBus.publish("m2_createCPPanel.contentLoaded");
}

export const getCPProperties = async (data, ctx) => {
  let input = {
    objects: [ctx.pselected],
    attributes: ["IMAN_reference"]
  }
  if (ctx.xrtSummaryContextObject) {
    input.objects.push(ctx.xrtSummaryContextObject);
  }
  await soaService.post("Core-2006-03-DataManagement", "getProperties", input);
}

export const loadProperty = (ctx) => {
  let input = {
    objects: [ctx.pselected],
    attributes: ["IMAN_reference"]
  }
  if (ctx.xrtSummaryContextObject) {
    input.objects.push(ctx.xrtSummaryContextObject);
  }
  soaService.post("Core-2006-03-DataManagement", "getProperties", input);
};

export const loadSelfTask = (data, ctx) => {
  const interval = setInterval(() => {
    if (data && data.dataProviders && data.dataProviders.selfTask) {
      // let test = tcViewModelObjectSvc.createViewModelObjectById(ctx.pselected.uid);
      // let test2 = viewModelObjectSvc.constructViewModelObjectFromModelObject( ctx.pselected );
      clearInterval(interval);
      let selfTask = viewModelObjectSvc.createViewModelObject(ctx.pselected);
      data.dataProviders.selfTask.update([selfTask], 1);
    }

    if (interval > 1000) {
      clearInterval(interval)
    }
  });
}

export default exports = {
  createCPPanelOpen,
  createObjects,
  reviseCP,
  reviseCPEvent,
  getCPProperties,
  loadProperty,
  loadSelfTask
}

app.factory('criticalPathService', () => exports);